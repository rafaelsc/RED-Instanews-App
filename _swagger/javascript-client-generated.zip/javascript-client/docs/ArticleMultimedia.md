# TopStories.ArticleMultimedia

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** |  | [optional] 
**format** | **String** |  | [optional] 
**height** | **Number** |  | [optional] 
**width** | **Number** |  | [optional] 
**type** | **String** |  | [optional] 
**subtype** | **String** |  | [optional] 
**caption** | **String** |  | [optional] 
**copyright** | **String** |  | [optional] 


