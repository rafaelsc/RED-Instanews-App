# TopStories.InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**[Article]**](Article.md) |  | [optional] 


