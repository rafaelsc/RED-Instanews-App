# TopStories.ArticleRelatedUrls

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggestedLinkText** | **String** |  | [optional] 
**url** | **String** |  | [optional] 


