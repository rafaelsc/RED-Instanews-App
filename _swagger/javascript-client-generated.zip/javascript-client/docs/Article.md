# TopStories.Article

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**section** | **String** |  | [optional] 
**subsection** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**_abstract** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**thumbnailStandard** | **String** |  | [optional] 
**shortUrl** | **String** |  | [optional] 
**byline** | **String** |  | [optional] 
**itemType** | **String** |  | [optional] 
**updatedDate** | **String** |  | [optional] 
**createdDate** | **String** |  | [optional] 
**publishedDate** | **String** |  | [optional] 
**materialTypeFacet** | **String** |  | [optional] 
**kicker** | **String** |  | [optional] 
**desFacet** | **[String]** |  | [optional] 
**orgFacet** | **[String]** |  | [optional] 
**perFacet** | **[String]** |  | [optional] 
**geoFacet** | **[String]** |  | [optional] 
**multimedia** | [**[ArticleMultimedia]**](ArticleMultimedia.md) |  | [optional] 
**relatedUrls** | [**[ArticleRelatedUrls]**](ArticleRelatedUrls.md) |  | [optional] 


