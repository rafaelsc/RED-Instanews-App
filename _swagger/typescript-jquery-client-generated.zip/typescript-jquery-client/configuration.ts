export class Configuration {
    apiKey: string;
    username: string;
    password: string;
    accessToken: string | (() => string);
}