export * from './StoriesApi';
import { StoriesApi } from './StoriesApi';
export const APIS = [StoriesApi];
